"""A simple exception for the EE library."""


class EEException(Exception):  # pylint: disable=g-bad-exception-name
  """A simple exception for the EE library."""
