Notebooks in this directory are being moved to:
https://github.com/google/earthengine-community/tree/master/guides/linked

Please refer to the new location.