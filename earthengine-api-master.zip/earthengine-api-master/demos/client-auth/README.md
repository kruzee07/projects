Earth Engine Demo: Client-Side Authentication
=============================================

This example demonstrates basic web authentication using the Earth Engine
JavaScript client library. To set up, follow the instructions in the
Developer Docs to [deploy an EE-based App Engine app](
    https://developers.google.com/earth-engine/app_engine_intro#deploying-app-engine-apps-with-earth-engine).
For the credentials section, you'll need an OAuth2 Client ID, not a Service Account.
