Visit the [Google Earth Engine NPM installation
page](https://developers.google.com/earth-engine/npm_install) for set up
instructions, or [download
ee_api_js.js](https://github.com/google/earthengine-api/blob/master/javascript/build/ee_api_js.js).
